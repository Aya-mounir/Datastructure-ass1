/*  name : ahmed said - id : 20200017
 *  name : aya mohamed mounir - id : 20200107
 *  name : shrouk ayman ali - id : 20200251
 *  name : youssef nasser - id : 20200674
 */

#include "FractionCalculator.h"

int main() {
    FractionCalculator fractionCalculator;
    fractionCalculator.perform();

}
