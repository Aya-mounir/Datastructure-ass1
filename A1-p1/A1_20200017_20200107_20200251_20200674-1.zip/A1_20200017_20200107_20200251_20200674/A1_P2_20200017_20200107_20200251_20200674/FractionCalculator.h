#ifndef UNTITLED_FRACTIONCALCULATOR_H
#define UNTITLED_FRACTIONCALCULATOR_H

class FractionCalculator{
public:
    FractionCalculator();
    void perform();

};
#endif

